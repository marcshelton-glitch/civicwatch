import { auth, currentUser } from '@clerk/nextjs/server'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)

// Validate that the app URL is a real https domain (prevents open redirect)
function getSafeAppUrl() {
  const url = process.env.NEXT_PUBLIC_APP_URL || ''
  if (!url.startsWith('https://') && !url.startsWith('http://localhost')) {
    throw new Error('NEXT_PUBLIC_APP_URL must be a valid https URL')
  }
  return url.replace(/\/$/, '') // strip trailing slash
}

export async function POST() {
  // ── 1. Auth check ──────────────────────────────────────────────────────────
  const { userId } = await auth()
  if (!userId) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const user = await currentUser()

  // ── 2. Don't let existing Pro users subscribe again ────────────────────────
  if (user?.publicMetadata?.isPro === true) {
    return Response.json({ error: 'Already subscribed' }, { status: 400 })
  }

  // ── 3. Create Stripe checkout session ─────────────────────────────────────
  try {
    const appUrl = getSafeAppUrl()

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        {
          price: process.env.STRIPE_PRO_PRICE_ID,
          quantity: 1,
        },
      ],
      // Pass Clerk userId so the webhook can find this user
      metadata: {
        clerkUserId: userId,
      },
      customer_email: user?.emailAddresses?.[0]?.emailAddress,
      success_url: `${appUrl}/dashboard?upgrade=success`,
      cancel_url: `${appUrl}/dashboard?upgrade=cancelled`,
      // Idempotency: one pending session per user at a time
      // Uses userId as idempotency key so rapid double-clicks reuse the same session
    }, {
      idempotencyKey: `checkout-${userId}-${Math.floor(Date.now() / 60000)}`, // 1-minute window
    })

    return Response.json({ url: session.url })

  } catch (err) {
    console.error('Stripe checkout error:', err.message)
    return Response.json({ error: 'Failed to create checkout session' }, { status: 500 })
  }
}
